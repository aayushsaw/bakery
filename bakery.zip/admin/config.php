<?php
// Admin Config - Points to parent directory config
require_once('../config_secure.php');
?>
